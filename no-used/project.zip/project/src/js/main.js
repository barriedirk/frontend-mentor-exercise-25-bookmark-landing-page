const $ = (selector) => document.querySelector(selector);

(async () => {
  // -- Mobile Menu Toggle Button ------
  const $header = $("#header");
  const $btnToggle = $("#headerBtnToggle");

  $btnToggle.addEventListener("click", async (evt) => {
    evt.preventDefault();

    const isExpanded = evt.target.getAttribute("aria-expanded");

    $btnToggle.setAttribute("aria-expanded", !isExpanded);

    isExpanded
      ? $header.classList.remove("is-expanded")
      : $header.classList.add("is-expanded");
  });
})();
